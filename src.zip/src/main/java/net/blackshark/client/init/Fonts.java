package net.blackshark.client.init;

import net.blackshark.client.impl.font.VanillaTextRenderer;

public class Fonts {
    //
    public static final VanillaTextRenderer VANILLA = new VanillaTextRenderer();
}
