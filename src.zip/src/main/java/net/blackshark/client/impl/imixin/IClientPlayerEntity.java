package net.blackshark.client.impl.imixin;

public interface IClientPlayerEntity {

    float getLastSpoofedYaw();
    float getLastSpoofedPitch();

}
