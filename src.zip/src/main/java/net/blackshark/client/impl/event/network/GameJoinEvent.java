package net.blackshark.client.impl.event.network;

import net.blackshark.client.api.event.Event;

public class GameJoinEvent extends Event {

}
