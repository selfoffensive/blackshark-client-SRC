package net.blackshark.client.impl.module.world;

import net.blackshark.client.api.config.Config;
import net.blackshark.client.api.config.setting.BooleanConfig;
import net.blackshark.client.api.event.listener.EventListener;
import net.blackshark.client.api.module.ModuleCategory;
import net.blackshark.client.api.module.ToggleModule;
import net.blackshark.client.impl.event.render.TargetEntityEvent;

public class NoHitboxModule extends ToggleModule {
    public NoHitboxModule(){
        super("NoHitbox","", ModuleCategory.WORLD);
    }
    Config<Boolean> allConfig = new BooleanConfig("All", "Ignores hitboxes allowing player to interact through entities", false);
    @EventListener
    public void onTargetEntity(TargetEntityEvent event) {
        event.setCanceled(allConfig.getValue());
    }

}
