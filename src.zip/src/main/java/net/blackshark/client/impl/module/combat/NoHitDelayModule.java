package net.blackshark.client.impl.module.combat;

import net.blackshark.client.api.event.listener.EventListener;
import net.blackshark.client.api.module.ModuleCategory;
import net.blackshark.client.api.module.ToggleModule;
import net.blackshark.client.impl.event.AttackCooldownEvent;

public class NoHitDelayModule extends ToggleModule {
    public NoHitDelayModule() {
        super("NoHitDelay", "Removes vanilla attack delay", ModuleCategory.COMBAT);
    }

    @EventListener
    public void onAttackCooldown(AttackCooldownEvent event) {
        event.cancel();
    }
}
