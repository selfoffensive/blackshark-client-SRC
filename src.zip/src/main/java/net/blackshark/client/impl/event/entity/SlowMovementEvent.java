package net.blackshark.client.impl.event.entity;

import net.minecraft.block.BlockState;
import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.Event;

@Cancelable
public class SlowMovementEvent extends Event {
    private final BlockState state;

    public SlowMovementEvent(BlockState state) {
        this.state = state;
    }

    public BlockState getState() {
        return state;
    }
}
