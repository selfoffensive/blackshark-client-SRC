package net.blackshark.client.impl.event.entity;

import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.Event;

@Cancelable
public class LevitationEvent extends Event {

}
