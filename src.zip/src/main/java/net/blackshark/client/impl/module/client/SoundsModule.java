package net.blackshark.client.impl.module.client;

import net.blackshark.client.api.config.Config;
import net.blackshark.client.api.config.setting.EnumConfig;
import net.blackshark.client.api.module.ModuleCategory;
import net.blackshark.client.api.module.ToggleModule;
import net.blackshark.client.impl.module.render.ESPModule;
import net.blackshark.client.util.math.timer.Timer;
import net.minecraft.sound.SoundEvent;

public class SoundsModule extends ToggleModule {
    public SoundsModule(){
        super("Sounds","s", ModuleCategory.CLIENT);
    }

}
