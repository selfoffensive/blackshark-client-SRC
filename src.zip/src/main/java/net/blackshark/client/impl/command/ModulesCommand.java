package net.blackshark.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.blackshark.client.init.Managers;
import net.blackshark.client.util.chat.ChatUtil;
import net.minecraft.command.CommandSource;
import net.minecraft.util.Formatting;
import net.blackshark.client.BlacksharkMod;
import net.blackshark.client.api.command.Command;
import net.blackshark.client.api.module.Module;
import net.blackshark.client.api.module.ToggleModule;

public class ModulesCommand extends Command {
    public ModulesCommand() {
        super("Modules", "Displays all client modules", literal("modules"));
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(c -> {
            StringBuilder modulesList = new StringBuilder();
            for (Module module : Managers.MODULE.getModules()) {
                String formatting = module instanceof ToggleModule t && t.isEnabled() ? "§s" : "§f";
                modulesList.append(formatting);
                modulesList.append(module.getName());
                modulesList.append(Formatting.RESET);
                // LOL
                if (!module.getName().equalsIgnoreCase(BlacksharkMod.isBaritonePresent() ? "Baritone" : "Speedmine")) {
                    modulesList.append(", ");
                }
            }
            ChatUtil.clientSendMessageRaw(" §7Modules:§f " + modulesList);
            return 1;
        });
    }
}
