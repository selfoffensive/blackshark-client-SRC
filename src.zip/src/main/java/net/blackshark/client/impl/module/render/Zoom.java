package net.blackshark.client.impl.module.render;

import net.blackshark.client.api.config.Config;
import net.blackshark.client.api.config.setting.NumberConfig;
import net.blackshark.client.api.module.ModuleCategory;
import net.blackshark.client.api.module.ToggleModule;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

public class Zoom extends ToggleModule {


    public Zoom(){
        super("Zoom","zooooooooooom", ModuleCategory.RENDER);   
    }

}
