package net.blackshark.client.impl.module.misc;

import net.blackshark.client.api.module.ModuleCategory;
import net.blackshark.client.api.module.ToggleModule;
import net.blackshark.client.impl.event.EventHandler;
import net.blackshark.client.impl.event.network.PacketEvent2;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class AutoUserMioModule extends ToggleModule {
    private boolean bypass = false;
    public AutoUserMioModule(){
        super("AutoUserMio","seeeex", ModuleCategory.MISCELLANEOUS);
    }



    @Override
    public void onEnable() {
        bypass = false;
    }




    @Override
    public void onDisable() {
        if (mc.player != null) mc.player.requestRespawn();
        bypass = false;
    }





    public void onUpdate() {
        if (mc.player == null || mc.world == null) return;
        if (mc.player.getHealth() == 0.0f) {
            mc.player.setHealth(20.0f);
            bypass = true;
            mc.setScreen(null);
            mc.player.setPosition(mc.player.getX(), mc.player.getY(), mc.player.getZ());
        }
        onUpdate();
    }




    @EventHandler
    public void onPacketSend(PacketEvent2.Send event) {
        if (bypass && event.getPacket() instanceof PlayerMoveC2SPacket) event.cancel();
    }


}
