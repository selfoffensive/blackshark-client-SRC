package net.blackshark.client.impl.event.network;

import net.blackshark.client.mixin.network.MixinClientPlayerEntity;
import net.blackshark.client.util.Globals;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.blackshark.client.api.event.Event;

/**
 * @author linus
 * @see MixinClientPlayerEntity
 * @since 1.0
 */
public class SetCurrentHandEvent extends Event implements Globals {
    //
    private final Hand hand;

    public SetCurrentHandEvent(Hand hand) {
        this.hand = hand;
    }

    public Hand getHand() {
        return hand;
    }

    public ItemStack getStackInHand() {
        return mc.player.getStackInHand(hand);
    }
}
