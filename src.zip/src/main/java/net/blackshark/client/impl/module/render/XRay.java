package net.blackshark.client.impl.module.render;

import net.blackshark.client.api.config.Config;
import net.blackshark.client.api.config.setting.BooleanConfig;
import net.blackshark.client.api.module.ModuleCategory;
import net.blackshark.client.api.module.ToggleModule;

public class XRay extends ToggleModule {
    public XRay(){
        super("XRay","xray", ModuleCategory.RENDER);
    }

}
