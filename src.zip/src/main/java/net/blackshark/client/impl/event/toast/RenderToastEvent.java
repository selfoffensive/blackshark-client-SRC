package net.blackshark.client.impl.event.toast;

import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.Event;

@Cancelable
public class RenderToastEvent extends Event {
}
