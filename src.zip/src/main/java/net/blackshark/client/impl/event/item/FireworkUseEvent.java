package net.blackshark.client.impl.event.item;

import net.blackshark.client.api.event.Event;

public class FireworkUseEvent extends Event {

}
