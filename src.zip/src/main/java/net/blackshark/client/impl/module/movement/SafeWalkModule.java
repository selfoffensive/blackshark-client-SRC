package net.blackshark.client.impl.module.movement;

import net.blackshark.client.api.module.ModuleCategory;
import net.blackshark.client.api.module.ToggleModule;
import net.blackshark.client.impl.event.ClipAtLedgeEvent2;
import net.blackshark.client.impl.event.EventHandler;

public class SafeWalkModule extends ToggleModule {
    public SafeWalkModule(){
        super("SafeWalk","savewalk", ModuleCategory.MOVEMENT);
    }


}
