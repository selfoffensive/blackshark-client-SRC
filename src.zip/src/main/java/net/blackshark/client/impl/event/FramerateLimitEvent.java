package net.blackshark.client.impl.event;

import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.Event;

/**
 *
 */
@Cancelable
public class FramerateLimitEvent extends Event {
    private int framerateLimit;

    public int getFramerateLimit() {
        return framerateLimit;
    }

    public void setFramerateLimit(int framerateLimit) {
        this.framerateLimit = framerateLimit;
    }
}
