package net.blackshark.client.impl.event.render;

import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.Event;

@Cancelable
public class RenderWorldBorderEvent extends Event {

}
