package net.blackshark.client.impl.event.text;

import net.blackshark.client.mixin.text.MixinTextVisitFactory;
import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.Event;

/**
 * @see MixinTextVisitFactory
 */
@Cancelable
public class TextVisitEvent extends Event {
    //
    private String text;

    /**
     * @param text
     */
    public TextVisitEvent(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
