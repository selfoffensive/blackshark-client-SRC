package net.blackshark.client.impl.command;

import baritone.api.command.ICommand;

/**
 * @author Shoreline
 * @since 1.0
 */
public class BaritoneCommand {
    private ICommand command;
}
