package net.blackshark.client.impl.event.render.entity;

import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.Event;

/**
 * @author linus
 * @since 1.0
 */
@Cancelable
public class RenderFireworkRocketEvent extends Event {

}
