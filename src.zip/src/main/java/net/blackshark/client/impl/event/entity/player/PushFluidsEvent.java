package net.blackshark.client.impl.event.entity.player;

import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.Event;

/**
 * @author linus
 * @since 1.0
 */
@Cancelable
public class PushFluidsEvent extends Event {

}
