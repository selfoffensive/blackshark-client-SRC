package net.blackshark.client.impl.event;

import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.Event;

@Cancelable
public class AttackCooldownEvent extends Event {

}
