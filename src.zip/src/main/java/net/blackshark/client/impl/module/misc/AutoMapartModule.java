package net.blackshark.client.impl.module.misc;

import net.blackshark.client.api.config.Config;
import net.blackshark.client.api.config.setting.BooleanConfig;
import net.blackshark.client.api.config.setting.NumberConfig;
import net.blackshark.client.api.event.EventStage;
import net.blackshark.client.api.event.listener.EventListener;
import net.blackshark.client.api.module.ModuleCategory;
import net.blackshark.client.api.module.ToggleModule;
import net.blackshark.client.impl.event.TickEvent;

/**
 * @author linus
 * @since 1.0
 */
public class AutoMapartModule extends ToggleModule {
    //
    Config<Float> rangeConfig = new NumberConfig<>("Range", "The range to place maps around the player", 0.1f, 6.0f, 10.0f);
    Config<Boolean> rotateConfig = new BooleanConfig("Rotate", "Rotates before placing maps", false);

    /**
     *
     */
    public AutoMapartModule() {
        super("AutoMapart", "Automatically places maparts on walls",
                ModuleCategory.MISCELLANEOUS);
    }

    @EventListener
    public void onTick(TickEvent event) {
        if (event.getStage() == EventStage.PRE) {

        }
    }
}
