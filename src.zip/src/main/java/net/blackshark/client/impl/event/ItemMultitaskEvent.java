package net.blackshark.client.impl.event;

import net.blackshark.client.mixin.MixinMinecraftClient;
import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.Event;

/**
 * Allows mining and eating at the same time
 *
 * @see MixinMinecraftClient
 */
@Cancelable
public class ItemMultitaskEvent extends Event {

}
