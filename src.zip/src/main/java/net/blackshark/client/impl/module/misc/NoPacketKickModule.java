package net.blackshark.client.impl.module.misc;

import net.blackshark.client.api.event.listener.EventListener;
import net.blackshark.client.api.module.ModuleCategory;
import net.blackshark.client.api.module.ToggleModule;
import net.blackshark.client.impl.event.network.DecodePacketEvent;

/**
 * @author linus
 * @since 1.0
 */
public class NoPacketKickModule extends ToggleModule {

    /**
     *
     */
    public NoPacketKickModule() {
        super("NoPacketKick", "Prevents getting kicked by packets", ModuleCategory.MISCELLANEOUS);
    }

    // TODO: Add more packet kick checks
    @EventListener
    public void onDecodePacket(DecodePacketEvent event) {
        event.cancel();
    }
}
