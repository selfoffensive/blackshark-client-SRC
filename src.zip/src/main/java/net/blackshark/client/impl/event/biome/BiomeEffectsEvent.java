package net.blackshark.client.impl.event.biome;

import net.minecraft.world.biome.BiomeParticleConfig;
import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.Event;

@Cancelable
public class BiomeEffectsEvent extends Event {

    private BiomeParticleConfig particleConfig;

    public BiomeParticleConfig getParticleConfig() {
        return particleConfig;
    }

    public void setParticleConfig(BiomeParticleConfig particleConfig) {
        this.particleConfig = particleConfig;
    }
}
