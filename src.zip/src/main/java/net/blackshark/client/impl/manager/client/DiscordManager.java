package net.blackshark.client.impl.manager.client;

/**
 * @author linus
 * @since 1.0
 */
public class DiscordManager {
    public void startRPC() {

    }
}
