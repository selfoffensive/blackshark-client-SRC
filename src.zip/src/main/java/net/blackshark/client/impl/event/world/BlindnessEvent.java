package net.blackshark.client.impl.event.world;

import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.Event;

@Cancelable
public class BlindnessEvent extends Event {

}
