package net.blackshark.client.impl.event.render.block;

import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.Event;

/**
 * @author linus
 * @since 1.0
 */
public class RenderTileEntityEvent extends Event {
    @Cancelable
    public static class EnchantingTableBook extends RenderTileEntityEvent {

    }
}
