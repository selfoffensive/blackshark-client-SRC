package net.blackshark.client.impl.module.movement;

import net.blackshark.client.api.event.listener.EventListener;
import net.blackshark.client.api.module.ModuleCategory;
import net.blackshark.client.api.module.ToggleModule;
import net.blackshark.client.impl.event.entity.JumpDelayEvent;

public class NoJumpDelayModule extends ToggleModule {
    public NoJumpDelayModule() {
        super("NoJumpDelay", "Removes the vanilla jump delay", ModuleCategory.MOVEMENT);
    }

    @EventListener
    public void onJumpDelay(JumpDelayEvent event) {
        event.cancel();
    }
}
