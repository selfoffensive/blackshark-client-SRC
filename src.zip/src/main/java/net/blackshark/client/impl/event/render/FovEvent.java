package net.blackshark.client.impl.event.render;

import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.Event;

@Cancelable
public class FovEvent extends Event {
    private double fov;

    public double getFov() {
        return fov;
    }

    public void setFov(double fov) {
        this.fov = fov;
    }
}
