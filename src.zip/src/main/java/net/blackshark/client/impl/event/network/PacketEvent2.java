package net.blackshark.client.impl.event.network;

import net.blackshark.client.api.event.Event;

import net.minecraft.network.packet.Packet;

public class PacketEvent2 extends Event {
    private final Packet<?> packet;

    public PacketEvent2(Packet<?> packet) {
        this.packet = packet;
    }

    public <T extends Packet<?>> T getPacket() {
        return (T) this.packet;
    }

    public static class Send extends PacketEvent2 {
        public Send(Packet<?> packet) {
            super(packet);
        }
    }

    public static class Receive extends PacketEvent2 {
        public Receive(Packet<?> packet) {
            super(packet);
        }
    }

    public static class SendPost extends PacketEvent2 {
        public SendPost(Packet<?> packet) {
            super(packet);
        }
    }

    public static class ReceivePost extends PacketEvent2 {
        public ReceivePost(Packet<?> packet) {
            super(packet);
        }
    }
}
