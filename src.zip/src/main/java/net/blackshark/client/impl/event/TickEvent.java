package net.blackshark.client.impl.event;

import net.blackshark.client.api.event.StageEvent;

/**
 * @author linus
 * @since 1.0
 */
public class TickEvent extends StageEvent {

}
