package net.blackshark.client.impl.event;

import net.blackshark.client.api.event.Event;

public class FinishLoadingEvent extends Event {
}
