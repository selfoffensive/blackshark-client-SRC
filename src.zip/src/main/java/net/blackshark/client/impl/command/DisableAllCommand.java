package net.blackshark.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.blackshark.client.init.Managers;
import net.blackshark.client.util.chat.ChatUtil;
import net.minecraft.command.CommandSource;
import net.blackshark.client.api.command.Command;
import net.blackshark.client.api.module.Module;
import net.blackshark.client.api.module.ToggleModule;

/**
 * @author Shoreline
 * @since 1.0
 */
public class DisableAllCommand extends Command {
    /**
     *
     */
    public DisableAllCommand() {
        super("DisableAll", "Disables all enabled modules", literal("disableall"));
    }

    @Override
    public void buildCommand(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(c -> {
            for (Module module : Managers.MODULE.getModules()) {
                if (module instanceof ToggleModule toggleModule && toggleModule.isEnabled()) {
                    toggleModule.disable();
                }
            }
            ChatUtil.clientSendMessage("All modules are disabled");
            return 1;
        });
    }
}
