package net.blackshark.client.impl.event.entity.player;

import net.blackshark.client.api.event.Cancelable;
import net.blackshark.client.api.event.StageEvent;

@Cancelable
public class PlayerJumpEvent extends StageEvent {

}
