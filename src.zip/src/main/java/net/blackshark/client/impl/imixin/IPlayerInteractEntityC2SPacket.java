package net.blackshark.client.impl.imixin;

import net.blackshark.client.util.network.InteractType;
import net.minecraft.entity.Entity;

/**
 *
 */
public interface IPlayerInteractEntityC2SPacket {
    /**
     * @return
     */
    Entity getEntity();

    /**
     * @return
     */
    InteractType getType();
}
