package net.blackshark.client.api;

/**
 * @author linus
 * @since 1.0
 */
public interface Identifiable {
    /**
     * @return
     */
    String getId();
}
