package net.blackshark.client.api.social;

public enum SocialRelation {
    FRIEND
}
