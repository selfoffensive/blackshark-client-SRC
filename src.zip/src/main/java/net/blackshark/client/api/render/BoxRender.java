package net.blackshark.client.api.render;

public enum BoxRender {
    FILL,
    OUTLINE
}
