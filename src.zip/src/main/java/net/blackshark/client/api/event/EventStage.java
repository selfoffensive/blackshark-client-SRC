package net.blackshark.client.api.event;

public enum EventStage {
    PRE,
    POST
}
